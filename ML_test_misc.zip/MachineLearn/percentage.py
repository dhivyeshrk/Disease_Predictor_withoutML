import csv
import matplotlib.pyplot as plt

with open("To_process2_fin.csv","r") as f:
    data=f.readlines()
final=[]
for line in data:
    temp=[]
    st=line.find("Within all the people")
    per_ind=[i-4 for i in range(st,len(line)) if line.startswith("report",i)]
    for x in per_ind:
        
        for y in range(x+20,len(line)):
            sym=[]
            
            if line[y]==",":
                end_pt=y
                break
            elif line[y]==".":
                end_pt=y
                break
        
        s=line[x+17:end_pt]
        s1=line[x:x+2]
        sym.append(s)
        sym.append(int(s1))


        temp.append(sym)
        
        
    final.append(temp)
    
print(final)
with open("percent.csv","w") as f:
    csv_writer=csv.writer(f)
    csv_writer.writerow(["percentage"])
    csv_writer.writerows(final)

    
        
        
