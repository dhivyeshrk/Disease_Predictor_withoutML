'''def count(s):
    countA=countT=countC=countG=0
    for x in s:
        if x=='A':
            countA+=1
        elif x=='T':
            countT=1
        elif x=='C':
            countC+=1
        else:
            countG+=1
    print('A: ',countA,"T: ",countT,"C: ",countC,"G: ",countG)
count('ATCGCGCGATCGATGCA')'''
        
def count2(s):
    dic={}
    dic['A']=dic['T']=dic['C']=dic['G']=0
    for x in s:
        dic[x]+=1
    print(((dic['G']+dic['C'])/(dic['G']+dic['C']+dic['T']+dic['A']))*100)
count2('ATCGCGCGATCGATGCA')

'''def seq(s1,s2):
    count=0
    if(len(s1)==len(s2)):
     for i in range(len(s1)):
        if s1[i]!=s2[i]:
            count+=1
     print(count)
    else:
        print("lengths should be same")
s1='ATCGCGCGATCGATGCA'
s2="ATGGCAGATCAGTCAGC"
seq(s1,s2)'''