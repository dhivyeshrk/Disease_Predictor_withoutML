n=input()
key=int(input())
st=""
for x in n:
    
    if (ord(x)+key)>90:
        st+=chr((ord(x)+key)-26)
    else:
        st+=chr((ord(x)+key))
    
        

print(st)
