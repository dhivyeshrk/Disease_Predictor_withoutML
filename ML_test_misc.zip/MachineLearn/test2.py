import pandas as pd
l=[]
with open("To_process2_fin.csv","r") as f:
    data=f.readlines()
for line in data:
    not_risk=line.find("On the other hand")
    end_pt=line.find(".",not_risk)
    st=line.find("age",not_risk)
    fend=line.find("years",st)
    l.append(line[st:fend].split())

    '''# age_ind = [i for i in range(len(line)) if line.startswith("age", i)] # contains all starting indices of age
    while(line.find("years",st)<end_pt):
        st=line.find("age",fend)
        fend=line.find("years",st)
        l.append(line[st:fend])'''
print(l)

