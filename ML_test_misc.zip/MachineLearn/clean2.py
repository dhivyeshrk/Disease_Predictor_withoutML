with open("To_process2_fin.csv","r") as f:
    data=f.read()
for line in data:
    line.find("age")