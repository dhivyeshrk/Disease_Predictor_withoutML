import csv
with open("To_process.csv","r") as f:
    data=f.readlines()
l=[]
for line in data:
    k=[]
    if line.find("The symptoms that are highly suggestive")>0:
        st=line.find("highly suggestive of")
        end=line.find("without those symptoms")
        st1=line.find("are",st)
        st=line[st1+4:end]
        k.append(st)
        l.append(k)
    else:
        l.append(["NULL"])
with open("Processed.csv","w") as f:
    csv_writer=csv.writer(f)
    csv_writer.writerow(["symptoms"])
    csv_writer.writerows(l)
