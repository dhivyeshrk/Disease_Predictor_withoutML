import sys
import matplotlib
import pandas as pd
import sys
import matplotlib.pyplot as plt
import numpy as np
l=[]
l1=[]
for i in range(0,796):
    l.append(i)

file=pd.read_csv("newline.csv")
file1=pd.DataFrame(file,index=l)
file2=pd.read_csv("newpercent.csv")

inp=input()

for i in range(len(file1["Diseases"])):
    if file1["Diseases"][i]==inp:
        print(i,"->",file1["Diseases"][i])
        print(i)
        break
with open("newpercent.csv","r") as f:
    data=f.readlines()
for j in range(len(data)):
    if i==j:
        final=data[i+1]
        break
'''st=end=0
while(final.find("]",st)<len(final)):
        st=final.find('[',end)
        end=final.find(']',st)
        l1.append(final[st+1:end])
print(l1)

'''
def findOccurrences(s, ch):
    return [i for i, letter in enumerate(s) if letter == ch]
sf=findOccurrences(final,'[')
lf=findOccurrences(final,']')
'''st=end=0
print(type(final))
st=final.find('[',end)
end=final.find(']',st)
l1.append(final[st+1:end])'''
for i in range(len(sf)):
    strg=final[sf[i]+1:lf[i]]
    l1.append(strg)
k=[]
for x in l1:
    k.append(x.split(","))
print(k)
per=[]
label=[]
for i in range(len(k)):
    per.append(k[i][1])
    label.append(k[i][0])
y = np.array(per)
    
plt.pie(y,labels=label)
plt.show()

plt.savefig(sys.stdout.buffer)
sys.stdout.flush()

















