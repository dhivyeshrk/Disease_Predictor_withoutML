import csv
import pandas as pd

# with open("Disease_and_Symptoms_final.csv", "r", encoding="utf-8") as f:
#     data = f.readlines()

df = pd.read_csv("Diseases_and_Symptoms_final.csv")
head_df = df.head()
symptoms = ["anxiety and nervousness", "depression", "insomnia"]
test = df.groupby(['diseases'])
df["sum"] = df[symptoms].sum(axis=1)
t = df.groupby(['sum'], sort=True)
s = df.nlargest(10, "sum").sort_values('sum', ascending=False)
min_df = s
most_df = s

# test2 = df.sum(axis=1) # axis = 1 means rows. axis = 0 means columns.
# f = s.describe()['sum'].iloc[2:3]  # standard deviation.

while min_df['sum'].std() >= 5:
    min_df = min_df[:-1]
most_df = min_df
while most_df['sum'].std() >= 2:
    most_df = most_df[:-1]

# print(s.describe())
# k = s['Diseases'].iloc[0:3]

most_probable_dis = most_df['diseases'].to_numpy()
less_probable_dis = [i for i in min_df['diseases'].to_numpy() if i not in most_probable_dis]

print(most_probable_dis)
print(less_probable_dis)



