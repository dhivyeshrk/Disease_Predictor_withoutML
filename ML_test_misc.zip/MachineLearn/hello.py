import pandas as pd
import csv
file=pd.read_csv("dhivyesh_data.xls")

k1=list(file["Diseases"])
final=[]

for x in k1:
    some=[]
    some.append(x)
    final.append(some)
print(final)
'''with open("dis.csv","w") as f1:
    csv_writer=csv.writer(f1)
    csv_writer.writerow(["Diseases"])
    csv_writer.writerows(final)'''


with open("To_process2_fin.csv") as f:
    data=f.readlines()
risk=[]
for line in data:
    result=[]
    if line.find("On the other hand")>0: 
     if line.find("age")==-1:
            risk.append(["NULL"])
     elif line.find("age")<(line.find("On the other hand")):
        
        end_pt=line.find("On the other hand")
        
        age_ind=[i for i in range(end_pt) if line.startswith("age",i,end_pt)]
        for l_ind in age_ind:
                age = line[l_ind+3:line.find("years", l_ind)]
                result.append(age)
        risk.append(result)
     else:
         risk.append(["NULL"])
    elif line.find("Within all the people")>0:
        if line.find("age")==-1:
            risk.append(["NULL"])


        elif line.find("age")<(line.find("Within all the people")):
        
            end_pt=line.find("Within all the people")
        
            age_ind=[i for i in range(end_pt) if line.startswith("age",i,end_pt)]
            for l_ind in age_ind:
                    age = line[l_ind+3:line.find("years", l_ind)]
                    result.append(age)
            risk.append(result)
        
            
        else:
            risk.append(["NULL"])
            

print(risk)
k=["riskers"]
last=[]
hey=[]


with open("mydata1.csv","w") as f:
    csv_writer=csv.writer(f)
    csv_writer.writerow(["riskers"])
    csv_writer.writerows(risk)
