import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
l=[]
l1=[]
for i in range(0,796):
    l.append(i)

file=pd.read_csv("Disease_List_Final.csv")
file1=pd.DataFrame(file,index=l)

inp=input()
# print(file1["Diseases"].iloc[[29]])
# print((file1["Diseases"].iloc[[29]])=="Injury to the hip")
for i in range(len(file1["Diseases"])):
    if file1["Diseases"][i]==inp:
        print(i,"->",file1["Diseases"][i])
        break
with open("mydata.csv","r") as f:
    data=f.readlines()
for j in range(len(data)):
    if i==j:
        final=data[i+1]
        break

final_list=final.split(",")
if final_list[0].strip()=='0':
    print("Nobody")
    exit()
final_lastlist=[]
for i in range(len(final_list)):
    temp=[]
    final_list[i]=final_list[i].strip()
    temp.append(final_list[i])
    temp.append((1/(len(final_list)))*100)

    final_lastlist.append(temp)
per=[]
label=[]
print(final_lastlist)
for i in range(len(final_lastlist)):
    per.append(final_lastlist[i][1])
    label.append(final_lastlist[i][0])
y=np.array(per)
plt.pie(y,labels=label)
plt.show()

