
        sym[0]=line[x+17:end_pt]
        sym[1]=line[x:x+2]
        temp.append(list(sym))