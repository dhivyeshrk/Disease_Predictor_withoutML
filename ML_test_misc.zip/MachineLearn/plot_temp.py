import pandas as pd
l=[]
for i in range(0,796):
    l.append(i)

file=pd.read_csv("newline.csv")
file1=pd.DataFrame(file,index=l)
file2=pd.read_csv("newpercent.csv")

inp=input()

for i in range(len(file1["Diseases"])):
    if file1["Diseases"][i]==inp:
        print(i)
        break
print(file.iloc[i])
file3=pd.DataFrame(file2,index=l)
target=file3.iloc[[i]]

print(target)







